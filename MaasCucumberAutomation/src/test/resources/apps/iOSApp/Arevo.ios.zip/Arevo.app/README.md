# Arevo - iOS application
This is the codebase for the iOS application [Arevo](https://apps.apple.com/au/app/arevo-journey-planner/id1452470753)

![Arevo Logo](https://www.arevo.com.au/content/dam/racv/images/on-the-road/mobility-as-a-service/arevo-header-desktop.jpg)
## Project setup

* Install Cocoapods if not already:

        sudo gem install cocoapods
* For install Mapbox 6.x SDK, Generate a .nettrc file into computer:

        cd ~
        touch .netrc

* Edit the .netrc file and insert the required keys from the "**arevo iOS secrets (bitrise.io)**" entry in LastPass:

        machine api.mapbox.com
        login mapbox
        password  <MapBox SDK Key>
* Install the project dependencies:

        pod install
* Determine what version of Swift you have:

        swift --version
* Install swift variable injector from the tag that correlates to the Swift version you are running. To determine the tag, go to [variable-injector Releases page](https://github.com/LucianoPAlmeida/variable-injector/releases) and locate the tag for your Swift version. Once identified, set the `TAG` env var and install `variable-injector`:

        # e.g. for Swift 5.3 you need tag 0.3.3
        export TAG=0.3.3
        curl -ssl https://raw.githubusercontent.com/LucianoPAlmeida/variable-injector/master/scripts/build-and-install.sh | sh

* Generate a secrets script template for injection into the application:

        cd Arevo/Secrets
        ./setup-development-secrets.sh

* Edit the created `development-secrets.sh` file and insert the required keys from the "**arevo iOS secrets (bitrise.io)**" entry in LastPass
* Open the `Arevo.xcworkspace` in XCode, you should now be able to successfully build and run the application
Warning: If updating the values of your keys, be aware sometimes xCode will cache, so try a clean if your old values are remaining

**Important:** Do not save new API keys directly in the project, but add them instead into that file and make sure the updated version is accessible for other developers ( but not committed in the repo ).  
All keys should also be added on the CI side to the secret keys in Bitrise.

## Project Schemes & Environment Configurations

### Mock-Debug
An environment providing mocked data to allow access to features that are still in development on the backend.

### Development-Debug
A potentially unstable backend environment, used for development of features.

### Staging-Release
Release candidate environment used for testing a realse before going live.

### Production-Release
Live production environment. Should not be used for testing or development purposes.


Environments are configured using xcconfig file located in `Support FIles/xcconfigs`. These are then assigned to the projects configurations accordingly. Schemes are then assigned an environment configuratoin accordingly. Environment configurations have access to preprocessor macros which can be found in their corresponding xcconfig file. These macros can be used to conditionally compile code wrapped in `#if ENV #endif` blocks.

## API Keys & Secrets
This project uses envrionment variables injected into swift code at build time to help prevent API keys or other secrets being stored in the source repositories.

### Adding keys
Modify the entries in `EnvironmentSecrets.swift` to update or add entries.
Also be sure to update the `setup-development-secrets.sh` and re-run afterwards to generate an up to date `development-secrets.sh`.

### How to Configure CI
1. Store the required variables as secrets within the CI that are then exposed as envrionment variables
2. Add a step that runs prior to the Xcode build that executes swift variable injector on the file "EnvironmentSecrets.swift" (to replace the variables in the template). Many CI solutions have a built in step for this.

See: https://github.com/LucianoPAlmeida/variable-injector for more info

NOTE: If you get an error like `dyld: Library not loaded: @rpath/lib_InternalSwiftSyntaxParser.dylib`, check where your version of Xcode is installed, and make sure you have a version installed at the default `Applications/Xcode.app`.

## Cocoapods

This project uses Cocoapods to handle 3rd party dependencies. The use of these libraries should be carefully considered and limited wherever possible. Also licenses must be reviewed before any library can be used.

Pods are currently excluded from the repo, meaning to run the project you will need to have Cocoapods installed on your machine, then run `pod install` to fetch the required dependencies *(see Cocoapods documentation if you need more details on how to do this)*.

As Pods are not included in the repo, the `Podfile` must include the supported version of the dependecy you wish to include *(see Cocoapods documentation for more details)*, as these will be re fetched by anyone else who wants to run the project, and the version to fetch therefore needs to be explicit to avoid support issues.


## Architecture Overview

The project uses a combination of SwiftUI as the primary toolkit, and UIKit where deemed more suitable. SwiftUI is not yet mature enough to handle all situations, so where necessary, UIKit can be used to bridge the gap, however SwiftUI will still be the primary and used whenever possible.

We are using a reactive architecture, taking advantage of Combine and state driven events for a unidirectional data flow.

Data is persisted in a Store model, and made available to the views via properties that use the `@Published` property wrapper. These stores are then injected into the views as `@ObservedObject` or `@EnvironmentObject`. Stores generally persist for the lifetime of the application, and are passed through the view stack and set in the init, or injected as environmentObjects depending on their scope. Either way, a store should only exist once within the application, however a singleton may or may not be appropriate, depending.

A store is typically initialised with a `dataSource` *(network api)*, a `persistenceProvider` *(cached data)*, and/or a `defaultsProvider` *(user defaults)*. The `dataSource` and `persistenceProvider` are protocols which define the functions used by the store for fetching data from its source. The `defaultsProvider` is the UserDefaults to access stored values. By defining a dataSource in this way, the store can interact with both the real data and apis, or mocked data during development and testing simply by injecting a mocked object that conforms to the protocols.

API access is handled by the `NetworkManager.sharedInstance` *(singleton)* that makes use of Combine publishers to access the remote API. The `NetworkManager` then conforms to the various protocols required by the stores.

Cached data access is handled by a `LocalStorageProvider`, which allows access to the file system and cached data.

The decision to use cached results or fetch them from the network is handled by the stores implementation.

UIKit views and controllers are managed using View Representables. When a store is required for a UIKit view, it should be set on the object when initialised in the `make` protocol method of the Representable, and then the Published properties of the store should be subscribed to individually to handle changes.


## App Configuration on Launch

https://racvone.atlassian.net/wiki/spaces/AREVO/pages/761299065/GET+app-config

## Versioning

The app version must be in the format of "x.x.x" (major, minor, point). This is due to the ability to deny specific versions and force the upgrade of old versions of the application. The App Configuration includes the data to enable this behavior. The format required is so that simple comparison can be made with the versions returned in the App Configuration.

## App Containers

The app containers are the entry point (or root controllers) for the rest of the app. There are 2 containers, one Hosting Container, and one App View Container.

The Hosting Container is our UIKit UIHostingController, which gives us control of UIKit, from deeper within the app when we need it. This is used for things like presenting UIAlerts above any current view. The Hosting container is managed by a Store which persists its state.

The App View Container is closer to the actual entry point of the app. It controls the launch events and handles the decisions on how to navigate based on current state (like user login or has seen walkthrough etc). This is managed by the View State which is responsible for maintaining all the business logic of this presentation.




## Card Presentation State

The Map Presentation View is the 'home' screen where various 'card' views are managed and presented from. This is managed by a more complex system of a Store, a View State, and a Coordinator, which combined control the state at any point for how and what cards are currently presented. The Store and ViewState are isolated from eachother, and are only coupled by the Coordinator.

### Store
The Store holds reference to the objects being used by the card views (eg. a details store object).

### View State
The View State maintains the presented state of the cards, and provides publishers that can be passed through to card views allowing them to dismiss, or present other card views themselves.

### Coordinator
The Coordinator is responsible for maintaining the state between the Store and the View State. It holds reference to both the Store and View State, and subscribes to changes to updates the objects as needed (eg. if a presented state is set to false on the View State, the Coordinator may set the Stores related object to nil)

### Map Presentation View
The Map Presentation View itself handles the decisions of what card is presented based on the View State and Store objects. There is logic within there that handles when one card may not present if another card is also presented, so relying on the View State to determine what is on screen is not necessarily accurate (eg. Search View Card will not be shown if there is a Search Result, but its state is still presented as its considered 'in the back stack' kinda).

### Interaction With Card Views
The ViewState provides a Binding for a cards presented state, and a PassthroughSubject to request presentation for that card view. Typically a card view would be provide a Binding to its presented state, allowing it to dismiss itself, and if it requires presenting another card itself (eg. a details card), also providing a PassthroughSubject which can be used to send the required object through to trigger another presentation. The PassthroughSubject is typically sent the object required to assign to the Stores object, but this may or may not be the end resulting object (eg. a response object may be sent, and the Coordinator may transform this into a List Item).




## Firebase Configuration

### Firebase Configuration Steps:
- Download the GoogleService-Info.plist
- Rename the file with the suffix for the environment
- Add new filename to environment xcconfig FIREBASE_PLIST_FILENAME
- Copy the REVERSED_CLIENT_ID into Arevo > Arevo > Info.plist under the **URL Types > (Item X) > URL Schemes > (Item)** section relating to the Scheme (dev, stage, prod), or if you're viewing the raw XML, then the appropriate `CFBundleURLSchemes` element of the `CFBundleURLTypes` entry
- MUST DO!!! Remove the API_KEY field from the plist file and add it to your EnvironmentsSecrets and CI (if needed)

